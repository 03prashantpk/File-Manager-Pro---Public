
### Hi ,I Am Rajiv Ranjan! <img src=" https://raw.githubusercontent.com/debdutgoswami/debdutgoswami/master/assets/gifs/Hi.gif" width="30px"> <br> <br>
<br>
![](https://komarev.com/ghpvc/?username=rajivranjanmars&color=blue)<br>
<h3>A budding programmer exploring new fields of development.</h3><br>

- 👨‍🏭 I’m currently pursuing **B.Tech CSE at Lovely Professional University** <br>
- 🏫 I’m currently learning **Problem Solving & Web Devlopment** <br>
- 🙌 I’m looking to collaborate on **web devlopment** <br>
- 🤔 I’m looking for help with **web devlopment and coompetitive programming**<br>
- 🥅 2021 Goals: **Contribute more  projects & learn new stacks** <br>
<br>
🕵 Take a look at my repositories and let's get in touch!<br>
<br>
[![Linkedin Badge](https://img.shields.io/badge/-rajivranjanmars-blue?style=flat-square&logo=Linkedin&logoColor=white&link=https://www.linkedin.com/in/rajivranjanmars/)](https://www.linkedin.com/in/rajivranjanmars/) 
[![Twitter Badge](https://img.shields.io/badge/-@rajivranjanmars-1ca0f1?style=flat-square&labelColor=1ca0f1&logo=twitter&logoColor=white&link=https://twitter.com/rajivranjanmars)](https://twitter.com/rajivranjanmars) 
[![Facebook Badge](https://img.shields.io/badge/-rajivranjanmars-3b5998?style=flat-square&labelColor=3b5998&logo=facebook&logoColor=white&link=https://www.facebook.com/rajivranjanmars)](https://www.facebook.com/rajivranjanmars) 
[![Instagram Badge](https://img.shields.io/badge/-@rajivranjanmars-E4405F?style=flat-square&logo=instagram&logoColor=white&link=https://www.instagram.com/rajivranjanmars)](https://www.instagram.com/rajivranjanmars) 

<br>
<br>
<br><br>
### 📈 Github Stats:<br>
<hr/><br>
<br>
<a href="https://github.com/rajivranjanmars">
<img align="center" src="https://github-readme-stats.vercel.app/api?username=rajivranjanmars&show_icons=true&include_all_commits=true&theme=midnight-purple&count_private=true">
</a>
<br><br>
<a href="https://github.com/remcohalman/github-readme-stats">
<img align="center" src="https://github-readme-stats.anuraghazra1.vercel.app/api/top-langs/?username=rajivranjanmars&layout=compact&theme=blue-green" />
</a>
<br>
<br><br>

[![GitHub Streak](https://github-readme-streak-stats.herokuapp.com/?user=rajivranjanmars)](https://git.io/streak-stats)

